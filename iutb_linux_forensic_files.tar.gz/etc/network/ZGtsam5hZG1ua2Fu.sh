##[gh0st_1n_the_machine]
## 
declare -a error_messages
error_messages[1]='ATTENTION!: THE BITBUCKET IS ALMOST FULL'
error_messages[2]='ACHTUNG!: DAS KOMPUTERMASCHINE IS NICHT GUD'
error_messages[3]='WARNING!: THE RAM FLANGES ARE IN THE OFF POSITION SAFE OPERATION OF RAM DRIVER IS NOT GUARANTEED!'
error_messages[4]='ERROR!: THE STACK ARRANGER IS NOT ENABLED BEWARE OF STACK COLLISIONS'
error_messages[5]='調試!: 如果發生堆棧衝突，則無法啟用堆棧!!!'
error_messages[6]='INFO!:  PURGING RAM BITS'
error_messages[7]='INFO!:  NODE GRAPH OUT OF DATE REBUILDING'
error_messages[8]='INFO!:  RETICULATING SPLINES'
error_messages[9]='WARNING!: DIHYDROGEN MONOXIDE DETECTED IN ATMOSPHERE'
error_messages[10]='INFO!: VENTING OXYGEN'
error_messages[11]='WARNING!: /dev/null IS 95% UTILIZED'
error_messages[12]='METTERE IN GUARDIA!: LE FLANGE DEL RAM SONO IN POSIZIONE OFF IL FUNZIONAMENTO SICURO DEL RAM DRIVER NON È GARANTITO!'


print_errors(){
    for i in {1..10000}; do
    tput setaf 1; echo "${error_messages[RANDOM%11]}" >> /var/log/messages ; tput setaf  7;
    sleep 5
#    if [[ $i -eq 3 ]]; then
#        introduce_self >> /var/log/messages
#    fi
    done
}

introduce_self(){
    echo "Wow this system is really broken huh?"
    sleep 4
    echo "Wonder if I can fix it"
    sleep 4
    echo "Gonna borrow your shell for a second"
    sleep 4
    echo "root@acmeweb:~# ls"
    ls -al ~ | echo
    sleep 4
    echo "Hmm"
    sleep 4
    echo "Nothing suspicious here"
    echo "root@acmeweb:~# ps"
    echo "Nothing strange here either."
    sleep 4
    echo "root@acmeweb:~# cd /etc"
    sleep 2
    echo "root@acmeweb:/etc/# ls -al"
    ls -al /etc/ | echo
    sleep 4
    echo "Wonder if theres anyting in the crontab"
    sleep 4
    echo "root@acmweb:/etc/ cat crontab"
    cat /etc/crontab | echo
    sleep 4
    echo "Hmm nothing here either"
    sleep 4 
    echo "Seems to be running all the time, so it could be a broken service."
    sleep 4
    echo "It might be worth running systemctl -l and, looking for things out of the ordinary"
    sleep 4
    echo "Oh by they way your computer isn't sentient, it's just haunted so there's nothing to worry about"
    sleep 4
}
print_errors
